/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.utl.iot.rifd;

import com.fazecast.jSerialComm.SerialPort;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

//20000801⸮5

/**
 *
 * @author guexa
 */
public class View extends javax.swing.JFrame {

    ConnectionMySQL conn;
    Statement stmt;
    ResultSet rs;
    
    //DefaultTableModel tblStudents = new DefaultTableModel();
    ADC adc;
    
    SerialPort serialP;
    InputStream input;
    OutputStream output;
    String chain = "";
    
    public View() throws Exception {
        
        initComponents();
        Connection();
        
        adc = new ADC();
        adc.start();
        
        //comoQuieras();
        
        conn = new ConnectionMySQL();
        
        stmt = conn.open().createStatement();
        rs = stmt.executeQuery("SELECT * FROM students");
        System.out.println("Succesfully Connection");
        
        
    }
    
//    public void comoQuieras(){
//        String chainS = "";
//        
//        chainS = txtEnrollment.getText().substring(0, 5);
//        System.out.println(chainS);
//    }
    
    public void Connection(){
        
        int baudios = 9600;
        
        String port = "COM8";
        
        serialP = SerialPort.getCommPort(port);
        serialP.setBaudRate(baudios);
        serialP.setNumDataBits(8);
        serialP.setNumStopBits(1);
        serialP.setParity(0);
        
        try{
            
            serialP.openPort();
            output = serialP.getOutputStream();
            input = serialP.getInputStream();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    public void recieveArduino() throws IOException {
        chain = "";
        
        while(input.available() > 0){
            chain += (char) input.read();
        }
        
        chain = chain.trim();
        
        System.out.println(chain);
        
        this.txtEnrollment.setText(chain);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtEnrollment = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(207, 187, 245));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(102, 0, 153)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        jLabel1.setText("Please identify yourself or you don't enter into the school");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, -1, -1));

        txtEnrollment.setColumns(20);
        txtEnrollment.setRows(5);
        jScrollPane1.setViewportView(txtEnrollment);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 650, 210));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 13, 783, 401));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new View().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtEnrollment;
    // End of variables declaration//GEN-END:variables
    
    class ADC extends Thread {

        @Override
        public void run() {
            while (true) {
                try {
                    recieveArduino();
                    Thread.sleep(1000);
                } catch (IOException ex) {
                    Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                    Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}