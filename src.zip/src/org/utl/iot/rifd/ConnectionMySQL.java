
package org.utl.iot.rifd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author guexa
 */
public class ConnectionMySQL {
    
    Connection conexion;
    
    public Connection open() throws Exception
    {
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://sort/Database";
        String user = "root";
        String password = "password";
        
        Class.forName(driver);
        
        conexion = DriverManager.getConnection(url, user, password);
        
        return conexion;
    }
    
    public void close()
    {
        try {
            if (conexion != null)
                conexion.close();
            } catch (SQLException ex) 
            {
                ex.printStackTrace();
            }
    }
    
}
